import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const crearProyectoSchema = z.object({
  codigo: z.string().max(50).optional(),
  nombre: z.string().min(3, 'El nombre debe tener al menos 3 caracteres').max(200),
  cliente_nombre: z.string().min(2, 'El nombre del cliente es obligatorio').max(150),
  descripcion: z.string().optional(),
});

// GET: Listar proyectos o detalle de uno por id
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ success: false, message: 'No autenticado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const proyectoId = searchParams.get('id');

    if (proyectoId) {
      const proyecto = await prisma.proyectoCaso.findFirst({
        where: { id: proyectoId, organizacion_id: session.organizacionId },
        include: {
          elementos_config: {
            include: {
              responsable: { select: { id: true, nombre_completo: true, cargo: true } },
              versiones: { orderBy: { created_at: 'desc' } },
            },
            orderBy: { created_at: 'desc' },
          },
          reuniones: { orderBy: { fecha: 'desc' } },
          lineas_base: {
            include: {
              versiones: true,
            },
            orderBy: { created_at: 'desc' },
          },
        },
      });

      if (!proyecto) {
        return NextResponse.json({ success: false, message: 'Proyecto no encontrado' }, { status: 404 });
      }

      return NextResponse.json({
        success: true,
        data: proyecto,
      });
    }

    const proyectos = await prisma.proyectoCaso.findMany({
      where: { organizacion_id: session.organizacionId },
      orderBy: { created_at: 'desc' },
      include: {
        _count: {
          select: {
            elementos_config: true,
            lineas_base: true,
            reuniones: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: proyectos,
    });
  } catch (error) {
    console.error('Error al listar proyectos:', error);
    return NextResponse.json({ success: false, message: 'Error interno del servidor' }, { status: 500 });
  }
}

// POST: Registrar nuevo proyecto / obra civil
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ success: false, message: 'No autenticado' }, { status: 401 });
    }

    if (!['SUPERADMIN', 'ADMINISTRADOR'].includes(session.rol)) {
      return NextResponse.json(
        { success: false, message: 'Solo administradores pueden crear proyectos' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const validation = crearProyectoSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Datos de proyecto inválidos', errors: validation.error.format() },
        { status: 400 }
      );
    }

    const { codigo, nombre, cliente_nombre } = validation.data;
    let codigoUpper = (codigo || '').trim().toUpperCase();
    if (!codigoUpper) {
      let countProyectos = await prisma.proyectoCaso.count({
        where: { organizacion_id: session.organizacionId },
      });
      const year = new Date().getFullYear();
      codigoUpper = `PRY-${year}-${String(countProyectos + 1).padStart(2, '0')}`;
      while (await prisma.proyectoCaso.findUnique({
        where: { organizacion_id_codigo: { organizacion_id: session.organizacionId, codigo: codigoUpper } },
      })) {
        countProyectos++;
        codigoUpper = `PRY-${year}-${String(countProyectos + 1).padStart(2, '0')}`;
      }
    }

    // Validar código único por organización
    const existente = await prisma.proyectoCaso.findUnique({
      where: {
        organizacion_id_codigo: {
          organizacion_id: session.organizacionId,
          codigo: codigoUpper,
        },
      },
    });

    if (existente) {
      return NextResponse.json(
        { success: false, message: `Ya existe un proyecto con el código '${codigoUpper}' en su organización.` },
        { status: 409 }
      );
    }

    const nuevoProyecto = await prisma.proyectoCaso.create({
      data: {
        organizacion_id: session.organizacionId,
        codigo: codigoUpper,
        nombre: nombre.trim(),
        cliente_nombre: cliente_nombre.trim(),
        fecha_inicio: new Date(),
        estado: 'EN_EJECUCION',
      },
    });

    // Auditoría inmutable (RNF-10)
    await prisma.auditoriaLog.create({
      data: {
        usuario_id: session.userId,
        accion: 'CREAR_PROYECTO',
        entidad: 'PROYECTO',
        entidad_id: nuevoProyecto.id,
        datos_nuevos: {
          codigo: nuevoProyecto.codigo,
          nombre: nuevoProyecto.nombre,
          cliente: nuevoProyecto.cliente_nombre,
        },
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: 'Proyecto registrado exitosamente',
        data: nuevoProyecto,
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Error al crear proyecto:', error);
    return NextResponse.json(
      { success: false, message: error.message || 'Error interno al registrar proyecto' },
      { status: 500 }
    );
  }
}
